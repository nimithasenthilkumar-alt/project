# Phishing Website Detection using Machine Learning

## Project Description
This project detects whether a website is phishing or legitimate using Machine Learning.

## Technologies Used
- Python
- Flask
- Scikit-learn
- HTML
- CSS

## Features
- Detect phishing websites
- User-friendly web interface
- Machine Learning prediction
- Responsive design

## How to Run

1. Install requirements

pip install -r requirements.txt

2. Run the application

python app.py

3. Open browser

http://127.0.0.1:5000