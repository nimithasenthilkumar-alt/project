from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    url = request.form['url']

    if "https" in url:
        result = "Legitimate Website ✅"
    else:
        result = "Phishing Website ⚠️"

    return render_template('index.html', prediction=result)

if __name__ == "__main__":
    app.run(debug=True)